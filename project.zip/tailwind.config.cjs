/** @type {import('tailwindcss').Config} */
    module.exports = {
      darkMode: ["class"],
      content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}",
        "./App.tsx"
      ],
      theme: {
        extend: {
          fontFamily: {
            sans: ['Inter', 'sans-serif'],
            mono: ['Space Mono', 'monospace'],
          },
          colors: {
            border: 'hsl(var(--border))',
            background: 'hsl(var(--background))',
            foreground: 'hsl(var(--foreground))',
            primary: {
              DEFAULT: '#00f2ff',
              foreground: '#000000'
            },
            secondary: {
              DEFAULT: '#ff00ff',
              foreground: '#ffffff'
            },
            accent: {
              DEFAULT: '#39ff14',
              foreground: '#000000'
            }
          }
        }
      },
      plugins: [require("tailwindcss-animate")],
    };