import React, { useState } from 'react';
    import { motion } from 'framer-motion';
    import { 
      Plus, 
      Search, 
      TrendingUp, 
      Users, 
      CreditCard, 
      Package,
      Trash2,
      ExternalLink,
      CheckCircle
    } from 'lucide-react';
    import Navbar from '../components/Navbar';

    const MOCK_TRANSACTIONS = [
      { id: '1', user: 'Alex Hunter', key: 'XJ92-KLP8-MN23-QW12', txn: 'TXN982341029', date: '2026-05-12', amount: 45 },
      { id: '2', user: 'Sarah Connor', key: 'PL09-ZX88-VB12-MK90', txn: 'TXN112233445', date: '2026-05-11', amount: 30 },
      { id: '3', user: 'John Wick', key: 'BB22-CC33-DD44-EE55', txn: 'TXN556677889', date: '2026-05-10', amount: 55 },
      { id: '4', user: 'Ellen Ripley', key: 'RR11-TT22-YY33-UU44', txn: 'TXN009988776', date: '2026-05-10', amount: 40 },
    ];

    export default function Admin() {
      const [searchKey, setSearchKey] = useState('');
      const [activeTab, setActiveTab] = useState('ledger');

      const filteredTransactions = MOCK_TRANSACTIONS.filter(t => 
        t.key.toLowerCase().includes(searchKey.toLowerCase()) ||
        t.user.toLowerCase().includes(searchKey.toLowerCase())
      );

      return (
        <div className="min-h-screen bg-[#050505] text-white pb-20">
          <Navbar />
          
          <main className="max-w-7xl mx-auto px-6 pt-32">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
              <div>
                <h1 className="text-4xl font-black font-mono mb-2">ADMIN <span className="text-[#ff00ff]">DASHBOARD</span></h1>
                <p className="text-white/50">Manage your inventory and track global transactions.</p>
              </div>
              
              <div className="flex gap-4">
                <button 
                  onClick={() => setActiveTab('add')}
                  className="flex items-center gap-2 px-6 py-3 bg-[#00f2ff] text-black font-bold rounded-xl hover:shadow-[0_0_15px_rgba(0,242,255,0.4)] transition-all"
                >
                  <Plus size={20} />
                  ADD NEW ID
                </button>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              {[
                { label: 'Total Revenue', value: '$12,450', icon: TrendingUp, color: 'text-[#39ff14]' },
                { label: 'Active Rentals', value: '48', icon: Package, color: 'text-[#00f2ff]' },
                { label: 'Total Users', value: '1,204', icon: Users, color: 'text-[#ff00ff]' },
                { label: 'Pending Verif.', value: '12', icon: CreditCard, color: 'text-yellow-400' },
              ].map((stat, i) => (
                <div key={i} className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-xl">
                  <div className="flex items-center justify-between mb-4">
                    <stat.icon className={stat.color} size={24} />
                    <span className="text-xs font-bold text-white/30 uppercase tracking-widest">Live</span>
                  </div>
                  <p className="text-white/50 text-sm mb-1">{stat.label}</p>
                  <p className="text-3xl font-black font-mono">{stat.value}</p>
                </div>
              ))}
            </div>

            {activeTab === 'ledger' ? (
              <div className="space-y-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <h2 className="text-xl font-bold font-mono flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-[#ff00ff] animate-pulse" />
                    TRANSACTION LEDGER
                  </h2>
                  
                  <div className="relative w-full md:w-96">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40" size={18} />
                    <input 
                      type="text" 
                      placeholder="Search by Key or User Name..."
                      value={searchKey}
                      onChange={(e) => setSearchKey(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-xl pl-12 pr-6 py-3 focus:outline-none focus:border-[#ff00ff] transition-colors"
                    />
                  </div>
                </div>

                <div className="bg-white/5 border border-white/10 rounded-2xl overflow-hidden backdrop-blur-xl">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-white/10 bg-white/5">
                          <th className="px-6 py-4 text-xs font-bold text-white/40 uppercase tracking-widest">User</th>
                          <th className="px-6 py-4 text-xs font-bold text-white/40 uppercase tracking-widest">Generated Key</th>
                          <th className="px-6 py-4 text-xs font-bold text-white/40 uppercase tracking-widest">TXN Number</th>
                          <th className="px-6 py-4 text-xs font-bold text-white/40 uppercase tracking-widest">Date</th>
                          <th className="px-6 py-4 text-xs font-bold text-white/40 uppercase tracking-widest">Amount</th>
                          <th className="px-6 py-4 text-xs font-bold text-white/40 uppercase tracking-widest">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {filteredTransactions.map((t) => (
                          <tr key={t.id} className={`hover:bg-white/5 transition-colors ${searchKey && (t.key.includes(searchKey) || t.user.includes(searchKey)) ? 'bg-[#ff00ff]/10' : ''}`}>
                            <td className="px-6 py-4 font-medium">{t.user}</td>
                            <td className="px-6 py-4">
                              <code className="text-[#00f2ff] font-mono bg-black/40 px-2 py-1 rounded">{t.key}</code>
                            </td>
                            <td className="px-6 py-4 text-white/60 font-mono text-sm">{t.txn}</td>
                            <td className="px-6 py-4 text-white/60 text-sm">{t.date}</td>
                            <td className="px-6 py-4 font-bold text-[#39ff14]">${t.amount}</td>
                            <td className="px-6 py-4">
                              <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-[#39ff14]/10 text-[#39ff14] text-[10px] font-bold uppercase">
                                <CheckCircle size={10} /> Verified
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            ) : (
              <div className="max-w-2xl mx-auto bg-white/5 border border-white/10 rounded-3xl p-8 backdrop-blur-xl">
                <h2 className="text-2xl font-bold mb-8 font-mono">ADD NEW <span className="text-[#00f2ff]">GAMING ID</span></h2>
                <form className="space-y-6">
                  <div className="grid grid-cols-2 gap-6">
                    <div className="col-span-2">
                      <label className="block text-white/40 text-xs uppercase tracking-widest mb-2">ID Title</label>
                      <input type="text" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-[#00f2ff]" placeholder="e.g. Valorant Radiant Account" />
                    </div>
                    <div>
                      <label className="block text-white/40 text-xs uppercase tracking-widest mb-2">Price Per Day ($)</label>
                      <input type="number" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-[#00f2ff]" placeholder="45" />
                    </div>
                    <div>
                      <label className="block text-white/40 text-xs uppercase tracking-widest mb-2">Membership Tier</label>
                      <select className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-[#00f2ff]">
                        <option>Diamond</option>
                        <option>Gold</option>
                        <option>Silver</option>
                      </select>
                    </div>
                    <div className="col-span-2">
                      <label className="block text-white/40 text-xs uppercase tracking-widest mb-2">Preview Image URL</label>
                      <input type="text" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-[#00f2ff]" placeholder="https://placehold.co/600x400" />
                    </div>
                  </div>
                  
                  <div className="flex gap-4 pt-4">
                    <button type="button" onClick={() => setActiveTab('ledger')} className="flex-1 py-4 rounded-xl bg-white/5 border border-white/10 font-bold hover:bg-white/10 transition-all">CANCEL</button>
                    <button type="submit" className="flex-1 py-4 rounded-xl bg-[#00f2ff] text-black font-black hover:shadow-[0_0_20px_rgba(0,242,255,0.5)] transition-all">PUBLISH ID</button>
                  </div>
                </form>
              </div>
            )}
          </main>
        </div>
      );
    }