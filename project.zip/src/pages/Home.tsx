import React, { useState } from 'react';
    import { motion } from 'framer-motion';
    import { Search, Filter, Zap, ShieldCheck, Clock } from 'lucide-react';
    import Navbar from '../components/Navbar';
    import IDCard from '../components/IDCard';
    import PurchaseModal from '../components/PurchaseModal';

    const MOCK_IDS = [
      { id: '1', title: 'Valorant Radiant Account', price: 45, tier: 'Diamond', image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=800' },
      { id: '2', title: 'CS2 Global Elite Prime', price: 30, tier: 'Gold', image: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&q=80&w=800' },
      { id: '3', title: 'Apex Legends Predator', price: 55, tier: 'Diamond', image: 'https://placehold.co/800x400' },
      { id: '4', title: 'League of Legends Challenger', price: 40, tier: 'Gold', image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&q=80&w=800' },
      { id: '5', title: 'Dota 2 Immortal Rank', price: 25, tier: 'Silver', image: 'https://images.unsplash.com/photo-1560253023-3ec5d502959f?auto=format&fit=crop&q=80&w=800' },
      { id: '6', title: 'Overwatch 2 Top 500', price: 35, tier: 'Diamond', image: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&q=80&w=800' },
    ];

    export default function Home() {
      const [isModalOpen, setIsModalOpen] = useState(false);
      const [selectedId, setSelectedId] = useState(null);

      const handleRent = (id: any) => {
        setSelectedId(id);
        setIsModalOpen(true);
      };

      return (
        <div className="min-h-screen bg-[#050505] text-white pb-20">
          <Navbar />
          
          {/* Hero Section */}
          <section className="pt-32 pb-16 px-6 relative overflow-hidden">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-[500px] bg-[#00f2ff]/10 blur-[120px] rounded-full -z-10" />
            
            <div className="max-w-7xl mx-auto text-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8"
              >
                <Zap size={16} className="text-[#39ff14]" />
                <span className="text-xs font-bold tracking-widest uppercase">Instant Access Marketplace</span>
              </motion.div>
              
              <motion.h1 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="text-5xl md:text-7xl font-black mb-6 tracking-tighter font-mono"
              >
                RENT THE <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00f2ff] to-[#ff00ff]">ULTIMATE</span> GAMING ID
              </motion.h1>
              
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-white/60 text-lg max-w-2xl mx-auto mb-12"
              >
                Access high-rank accounts, rare skins, and exclusive memberships instantly. Secure, verified, and ready for battle.
              </motion.p>

              <div className="flex flex-wrap justify-center gap-8 text-sm font-mono text-white/40">
                <div className="flex items-center gap-2">
                  <ShieldCheck size={18} className="text-[#00f2ff]" />
                  <span>VERIFIED ACCOUNTS</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock size={18} className="text-[#ff00ff]" />
                  <span>24/7 SUPPORT</span>
                </div>
                <div className="flex items-center gap-2">
                  <Zap size={18} className="text-[#39ff14]" />
                  <span>INSTANT DELIVERY</span>
                </div>
              </div>
            </div>
          </section>

          {/* Marketplace Grid */}
          <section className="max-w-7xl mx-auto px-6 py-12">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
              <h2 className="text-3xl font-bold font-mono">AVAILABLE <span className="text-[#00f2ff]">IDS</span></h2>
              
              <div className="flex gap-4">
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40" size={18} />
                  <input 
                    type="text" 
                    placeholder="Search games or ranks..."
                    className="bg-white/5 border border-white/10 rounded-xl pl-12 pr-6 py-3 focus:outline-none focus:border-[#00f2ff] transition-colors w-full md:w-64"
                  />
                </div>
                <button className="p-3 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-colors">
                  <Filter size={20} />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {MOCK_IDS.map((id, index) => (
                <motion.div
                  key={id.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <IDCard id={id} onRent={handleRent} />
                </motion.div>
              ))}
            </div>
          </section>

          <PurchaseModal 
            isOpen={isModalOpen} 
            onClose={() => setIsModalOpen(false)} 
            selectedId={selectedId}
          />
          
          <footer className="mt-24 border-t border-white/10 py-12 px-6">
            <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
              <div className="flex items-center gap-2">
                <Shield className="text-[#00f2ff]" size={24} />
                <span className="text-xl font-bold font-mono">ID RENTER</span>
              </div>
              <p className="text-white/40 text-sm">© 2026 ID RENTER. All rights reserved. Built for the elite.</p>
              <div className="flex gap-6 text-white/60 hover:text-white transition-colors">
                <a href="#" className="hover:text-[#00f2ff]">Terms</a>
                <a href="#" className="hover:text-[#ff00ff]">Privacy</a>
                <a href="#" className="hover:text-[#39ff14]">Telegram</a>
              </div>
            </div>
          </footer>
        </div>
      );
    }