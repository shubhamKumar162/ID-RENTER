import React from 'react';
    import { Link, useLocation } from 'react-router-dom';
    import { Shield, LayoutDashboard, Home as HomeIcon } from 'lucide-react';

    const Navbar = () => {
      const location = useLocation();
      const isAdmin = location.pathname.startsWith('/admin');

      return (
        <header className="fixed top-0 left-0 right-0 z-50 border-b border-white/10 bg-black/60 backdrop-blur-md">
          <nav className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2 group">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#00f2ff] to-[#ff00ff] flex items-center justify-center shadow-[0_0_15px_rgba(0,242,255,0.5)] group-hover:scale-110 transition-transform">
                <Shield className="text-white" size={24} />
              </div>
              <span className="text-2xl font-bold tracking-tighter text-white font-mono">
                ID <span className="text-[#00f2ff] drop-shadow-[0_0_8px_rgba(0,242,255,0.8)]">RENTER</span>
              </span>
            </Link>

            <div className="flex items-center gap-6">
              <Link 
                to="/" 
                className={`flex items-center gap-2 font-medium transition-colors ${location.pathname === '/' ? 'text-[#00f2ff]' : 'text-white/70 hover:text-white'}`}
              >
                <HomeIcon size={18} />
                <span className="hidden sm:inline">Marketplace</span>
              </Link>
              <Link 
                to="/admin" 
                className={`flex items-center gap-2 font-medium px-4 py-2 rounded-full border transition-all ${isAdmin ? 'bg-[#ff00ff]/20 border-[#ff00ff] text-[#ff00ff] shadow-[0_0_10px_rgba(255,0,255,0.3)]' : 'border-white/10 text-white/70 hover:border-[#ff00ff]/50 hover:text-white'}`}
              >
                <LayoutDashboard size={18} />
                <span>Admin</span>
              </Link>
            </div>
          </nav>
        </header>
      );
    };

    export default Navbar;