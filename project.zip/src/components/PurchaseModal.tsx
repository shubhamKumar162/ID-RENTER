import React, { useState } from 'react';
    import { motion, AnimatePresence } from 'framer-motion';
    import { X, QrCode, Upload, CheckCircle2, Copy, Send } from 'lucide-react';
    import { toast } from 'react-toastify';

    interface PurchaseModalProps {
      isOpen: boolean;
      onClose: () => void;
      selectedId: any;
    }

    const PurchaseModal: React.FC<PurchaseModalProps> = ({ isOpen, onClose, selectedId }) => {
      const [step, setStep] = useState(1);
      const [txnId, setTxnId] = useState('');
      const [generatedKey, setGeneratedKey] = useState('');

      const generateKey = () => {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let result = '';
        for (let i = 0; i < 16; i++) {
          result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
      };

      const handleNext = () => {
        if (step === 2) {
          if (!txnId) {
            toast.error("Please enter Transaction ID");
            return;
          }
          const key = generateKey();
          setGeneratedKey(key);
          setStep(3);
        } else {
          setStep(step + 1);
        }
      };

      const copyKey = () => {
        navigator.clipboard.writeText(generatedKey);
        toast.success("Key copied to clipboard!");
      };

      if (!isOpen) return null;

      return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
          />
          
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="relative w-full max-w-lg bg-[#0a0a0a] border border-white/10 rounded-3xl overflow-hidden shadow-[0_0_50px_rgba(0,242,255,0.15)]"
          >
            {/* Header */}
            <div className="p-6 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-[#00f2ff]/10 to-transparent">
              <div>
                <h2 className="text-xl font-bold text-white font-mono">SECURE RENTAL</h2>
                <p className="text-white/50 text-xs uppercase tracking-widest">Step {step} of 3</p>
              </div>
              <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                <X size={20} className="text-white/70" />
              </button>
            </div>

            <div className="p-8">
              <AnimatePresence mode="wait">
                {step === 1 && (
                  <motion.div 
                    key="step1"
                    initial={{ x: 20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    exit={{ x: -20, opacity: 0 }}
                    className="text-center"
                  >
                    <div className="mb-6 inline-block p-4 bg-white rounded-2xl">
                      <img 
                        src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=IDRENTER_PAYMENT_GATEWAY" 
                        alt="Payment QR"
                        className="w-48 h-48"
                      />
                    </div>
                    <h3 className="text-lg font-bold text-white mb-2">Scan to Pay</h3>
                    <p className="text-white/60 text-sm mb-8">
                      Please scan the QR code above and pay <span className="text-[#39ff14] font-bold">${selectedId?.price}</span> to proceed with the rental.
                    </p>
                    <button 
                      onClick={handleNext}
                      className="w-full py-4 rounded-xl bg-[#00f2ff] text-black font-black tracking-tighter hover:shadow-[0_0_20px_rgba(0,242,255,0.5)] transition-all"
                    >
                      I HAVE PAID
                    </button>
                  </motion.div>
                )}

                {step === 2 && (
                  <motion.div 
                    key="step2"
                    initial={{ x: 20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    exit={{ x: -20, opacity: 0 }}
                  >
                    <div className="space-y-6">
                      <div>
                        <label className="block text-white/60 text-xs uppercase tracking-widest mb-2">Transaction ID (TXN)</label>
                        <input 
                          type="text"
                          value={txnId}
                          onChange={(e) => setTxnId(e.target.value)}
                          placeholder="Enter 12-digit TXN ID"
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-4 text-white focus:outline-none focus:border-[#00f2ff] transition-colors font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-white/60 text-xs uppercase tracking-widest mb-2">Payment Screenshot</label>
                        <div className="border-2 border-dashed border-white/10 rounded-xl p-8 text-center hover:border-[#ff00ff]/50 transition-colors cursor-pointer group">
                          <Upload className="mx-auto mb-2 text-white/30 group-hover:text-[#ff00ff] transition-colors" size={32} />
                          <p className="text-white/40 text-sm">Click to upload or drag & drop</p>
                        </div>
                      </div>
                      <button 
                        onClick={handleNext}
                        className="w-full py-4 rounded-xl bg-[#ff00ff] text-white font-black tracking-tighter hover:shadow-[0_0_20px_rgba(255,0,255,0.5)] transition-all"
                      >
                        VERIFY PAYMENT
                      </button>
                    </div>
                  </motion.div>
                )}

                {step === 3 && (
                  <motion.div 
                    key="step3"
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="text-center"
                  >
                    <div className="w-20 h-20 bg-[#39ff14]/20 rounded-full flex items-center justify-center mx-auto mb-6 border border-[#39ff14]/50">
                      <CheckCircle2 className="text-[#39ff14]" size={40} />
                    </div>
                    <h3 className="text-2xl font-bold text-white mb-2">Payment Submitted!</h3>
                    <p className="text-white/60 text-sm mb-8">Your unique verification key has been generated.</p>
                    
                    <div className="bg-white/5 border border-white/10 rounded-xl p-6 mb-8 relative group">
                      <p className="text-xs text-white/40 uppercase tracking-widest mb-2">Your Rental Key</p>
                      <p className="text-2xl font-mono font-bold text-[#00f2ff] tracking-wider break-all">
                        {generatedKey}
                      </p>
                      <button 
                        onClick={copyKey}
                        className="absolute top-4 right-4 p-2 hover:bg-white/10 rounded-lg transition-colors"
                      >
                        <Copy size={16} className="text-white/60" />
                      </button>
                    </div>

                    <div className="bg-[#ff00ff]/10 border border-[#ff00ff]/30 rounded-xl p-4 text-left mb-8">
                      <div className="flex gap-3">
                        <Send className="text-[#ff00ff] shrink-0" size={20} />
                        <div>
                          <p className="text-white font-bold text-sm mb-1">SCREENSHOT THIS!</p>
                          <p className="text-white/70 text-xs leading-relaxed">
                            Send this Key and your Payment Screenshot to <span className="text-[#ff00ff] font-bold">@xx_shubham_410</span> on Telegram for instant verification.
                          </p>
                        </div>
                      </div>
                    </div>

                    <button 
                      onClick={onClose}
                      className="w-full py-4 rounded-xl bg-white/10 text-white font-bold hover:bg-white/20 transition-all"
                    >
                      CLOSE WINDOW
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </div>
      );
    };

    export default PurchaseModal;