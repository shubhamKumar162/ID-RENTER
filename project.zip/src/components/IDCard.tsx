import React from 'react';
    import { motion } from 'framer-motion';
    import { Trophy, Zap, CreditCard } from 'lucide-react';

    interface IDCardProps {
      id: {
        id: string;
        title: string;
        price: number;
        tier: string;
        image: string;
      };
      onRent: (id: any) => void;
    }

    const IDCard: React.FC<IDCardProps> = ({ id, onRent }) => {
      const getTierColor = (tier: string) => {
        switch (tier.toLowerCase()) {
          case 'diamond': return 'from-[#00f2ff] to-[#0066ff] text-white shadow-[0_0_15px_rgba(0,242,255,0.4)]';
          case 'gold': return 'from-[#ffd700] to-[#ff8c00] text-black shadow-[0_0_15px_rgba(255,215,0,0.4)]';
          default: return 'from-[#39ff14] to-[#00cc00] text-black shadow-[0_0_15px_rgba(57,255,20,0.4)]';
        }
      };

      return (
        <motion.div 
          whileHover={{ y: -8 }}
          className="relative group rounded-2xl overflow-hidden bg-white/5 border border-white/10 backdrop-blur-xl"
        >
          <div className="aspect-[16/9] overflow-hidden relative">
            <img 
              src={id.image} 
              alt={id.title} 
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
            <div className={`absolute top-4 right-4 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-gradient-to-r ${getTierColor(id.tier)}`}>
              {id.tier}
            </div>
          </div>

          <div className="p-6">
            <h3 className="text-xl font-bold text-white mb-2 font-mono group-hover:text-[#00f2ff] transition-colors">
              {id.title}
            </h3>
            
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2 text-white/60 text-sm">
                <Trophy size={14} className="text-[#ff00ff]" />
                <span>High Rank Account</span>
              </div>
              <div className="text-right">
                <span className="text-2xl font-black text-[#39ff14] drop-shadow-[0_0_8px_rgba(57,255,20,0.5)]">
                  ${id.price}
                </span>
                <span className="text-white/40 text-xs block">/ day</span>
              </div>
            </div>

            <button 
              onClick={() => onRent(id)}
              className="w-full py-3 rounded-xl bg-white/10 border border-white/20 text-white font-bold flex items-center justify-center gap-2 hover:bg-[#00f2ff] hover:text-black hover:border-[#00f2ff] transition-all duration-300 group/btn"
            >
              <CreditCard size={18} className="group-hover/btn:scale-110 transition-transform" />
              RENT NOW
            </button>
          </div>
          
          {/* Neon Glow Effect */}
          <div className="absolute -inset-px rounded-2xl border border-transparent group-hover:border-[#00f2ff]/50 transition-colors pointer-events-none" />
        </motion.div>
      );
    };

    export default IDCard;